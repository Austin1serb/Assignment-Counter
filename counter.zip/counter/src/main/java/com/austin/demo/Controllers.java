package com.austin.demo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;

@Controller
public class Controllers {

    @RequestMapping("/")
    public String increment(HttpSession session) {
        // If the count is not already in session
        if (session.getAttribute("count") == null) {
            session.setAttribute("count", 0);
        } else {
            // Increment the count by 1 using getAttribute and setAttribute
            int currentCount = (Integer) session.getAttribute("count");
            session.setAttribute("count", currentCount + 1);
        }
        return "redirect:/counter";
    }

    @RequestMapping("/counter")
    public String counter() {
        return "index.jsp";
    }

    @RequestMapping("/bonus")
    public String bonusIncrement(HttpSession session) {
        if (session.getAttribute("count") == null) {
            session.setAttribute("count", 0);
        } else {
            int currentCount = (Integer) session.getAttribute("count");
            session.setAttribute("count", currentCount + 2);
        }
        return "redirect:/counter";
    }

    @RequestMapping("/reset")
    public String resetCounter(HttpSession session) {
        session.setAttribute("count", 0);
        return "redirect:/counter";
    }
}
